import {
    browserLocalPersistence,
    browserSessionPersistence,
    createUserWithEmailAndPassword,
    onAuthStateChanged,
    sendPasswordResetEmail,
    setPersistence,
    signInWithEmailAndPassword,
    updateProfile
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { auth, firebaseConfigured } from "./firebase-config.js";

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const message = document.getElementById("authMessage");
let registrationInProgress = false;

function showMessage(text, kind) {
    message.textContent = text;
    message.dataset.kind = kind || "";
}

function setBusy(form, busy, pendingText) {
    const button = form.querySelector(".auth-submit");
    if (busy) {
        button.dataset.defaultLabel = button.textContent.trim();
        button.textContent = pendingText;
        button.disabled = true;
        form.setAttribute("aria-busy", "true");
        return;
    }

    button.textContent = button.dataset.defaultLabel || button.textContent;
    button.disabled = false;
    form.removeAttribute("aria-busy");
}

function getErrorMessage(error) {
    const messages = {
        "auth/email-already-in-use": "An account with this email already exists.",
        "auth/invalid-credential": "The email or password is incorrect.",
        "auth/invalid-email": "Enter a valid email address.",
        "auth/missing-password": "Enter your password.",
        "auth/weak-password": "Use a password with at least 8 characters.",
        "auth/operation-not-allowed": "Email and password sign-in is not enabled for this Firebase project.",
        "auth/configuration-not-found": "Firebase Authentication is not initialized. Enable Email/Password sign-in in Firebase Console.",
        "auth/invalid-api-key": "The Firebase web API key is invalid. Check the Firebase web app settings.",
        "auth/api-key-not-valid": "The Firebase web API key is invalid or restricted.",
        "auth/unauthorized-domain": "This website domain is not authorized in Firebase Authentication settings.",
        "auth/network-request-failed": "Could not reach Firebase. Check your internet connection.",
        "auth/too-many-requests": "Too many attempts. Wait a little and try again.",
        "auth/user-not-found": "No account was found for this email.",
        "auth/wrong-password": "The email or password is incorrect."
    };

    return messages[error.code] || "Firebase Authentication could not complete the request. Please try again.";
}

function requireFirebase() {
    if (firebaseConfigured && auth) {
        return true;
    }

    showMessage(
        "Firebase is not configured. Add the web app settings in frontend/firebase-config.js.",
        "error"
    );
    return false;
}

if (firebaseConfigured && auth) {
    onAuthStateChanged(auth, user => {
        if (user && !registrationInProgress) {
            window.location.replace("dashboard.html");
        }
    }, error => {
        console.error("Could not determine Firebase Authentication state.", error);
        showMessage("Could not verify your login. Refresh the page and try again.", "error");
    });
} else {
    showMessage(
        "Firebase is not configured. Add the web app settings in frontend/firebase-config.js.",
        "error"
    );
}

document.querySelectorAll("[data-password-toggle]").forEach(button => {
    button.addEventListener("click", () => {
        const input = document.getElementById(button.dataset.passwordToggle);
        const reveal = input.type === "password";
        input.type = reveal ? "text" : "password";
        button.textContent = reveal ? "Hide" : "Show";
        button.setAttribute("aria-pressed", String(reveal));
    });
});

if (loginForm) {
    loginForm.addEventListener("submit", async event => {
        event.preventDefault();
        if (!requireFirebase()) return;

        const email = document.getElementById("email").value.trim().toLowerCase();
        const password = document.getElementById("password").value;
        const remember = document.getElementById("rememberMe").checked;

        showMessage("", "");
        setBusy(loginForm, true, "Signing in…");
        try {
            await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence);
            await signInWithEmailAndPassword(auth, email, password);
            showMessage("Signed in. Opening your dashboard…", "success");
            window.location.replace("dashboard.html");
        } catch (error) {
            console.error("Firebase sign-in failed.", error);
            showMessage(getErrorMessage(error), "error");
            setBusy(loginForm, false);
        }
    });

    document.getElementById("resetPassword").addEventListener("click", async () => {
        if (!requireFirebase()) return;

        const email = document.getElementById("email");
        email.value = email.value.trim();
        if (!email.value || !email.checkValidity()) {
            email.reportValidity();
            showMessage("Enter your email address first, then request a reset link.", "error");
            email.focus();
            return;
        }

        const resetButton = document.getElementById("resetPassword");
        resetButton.disabled = true;
        showMessage("Sending password reset email…", "");
        try {
            await sendPasswordResetEmail(auth, email.value.toLowerCase());
            showMessage("If an account exists for this address, a password reset email has been sent.", "success");
        } catch (error) {
            console.error("Firebase password reset request failed.", error);
            showMessage(getErrorMessage(error), "error");
        } finally {
            resetButton.disabled = false;
        }
    });
}

if (registerForm) {
    registerForm.addEventListener("submit", async event => {
        event.preventDefault();
        if (!requireFirebase()) return;
        if (!registerForm.reportValidity()) return;

        const name = document.getElementById("fullName").value.trim();
        const email = document.getElementById("registerEmail").value.trim().toLowerCase();
        const password = document.getElementById("registerPassword").value;
        const confirmation = document.getElementById("confirmPassword").value;

        if (!name) {
            showMessage("Enter your full name.", "error");
            document.getElementById("fullName").focus();
            return;
        }
        if (password.length < 8) {
            showMessage("Choose a password with at least 8 characters.", "error");
            return;
        }
        if (password !== confirmation) {
            showMessage("The passwords do not match.", "error");
            return;
        }

        registrationInProgress = true;
        showMessage("", "");
        setBusy(registerForm, true, "Creating account…");
        try {
            await setPersistence(auth, browserLocalPersistence);
            const credential = await createUserWithEmailAndPassword(auth, email, password);
            try {
                await updateProfile(credential.user, { displayName: name });
            } catch (error) {
                console.error("Firebase account was created, but its display name could not be saved.", error);
                showMessage("Your account was created, but your profile name could not be saved. Opening your dashboard…", "success");
                window.location.replace("dashboard.html");
                return;
            }

            showMessage("Account created. Opening your dashboard…", "success");
            window.location.replace("dashboard.html");
        } catch (error) {
            registrationInProgress = false;
            console.error("Firebase account registration failed.", error);
            showMessage(getErrorMessage(error), "error");
            setBusy(registerForm, false);
        }
    });
}
