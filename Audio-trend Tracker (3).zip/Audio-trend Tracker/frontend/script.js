
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { httpsCallable } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-functions.js";
import { auth, firebaseConfigured, functions } from "./firebase-config.js";
import { createInitialMockData, TRACKER_STORAGE_KEY } from "./data.js";

const MOCK_STORAGE_KEY = TRACKER_STORAGE_KEY;
const INDIAN_TRENDS_SEEDED_KEY = "audioTrendIndianTrendsSeeded";
const INDIAN_AUDIOS_SEEDED_KEY = "audioTrendIndianAudiosSeeded";

const initialMockData = createInitialMockData();

const seededIndianTrends = initialMockData.trends.filter(trend =>
    trend.id.startsWith("trend-in-")
);
const seededIndianUsages = initialMockData.usages.filter(usage =>
    usage.id.startsWith("usage-in-")
);
const seededIndianAudios = initialMockData.audios.filter(audio =>
    audio.id.startsWith("audio-in-")
);
const seededIndianAudioUsages = initialMockData.usages.filter(usage =>
    usage.id.startsWith("usage-audio-in-")
);

let audios = [];
let trends = [];
let usages = [];

let audioChart;
let viralityChart;
let analyticsBarChart;
let trendChart;
let generatedPreviewContext;
let generatedPreviewTimer;

const artworkImages = {
    audio: {
        night: "photo-1519608487953-e999c86e7455",
        gold: "photo-1490750967868-88aa4486c946",
        velvet: "photo-1516280440614-37939bbacd81",
        rain: "photo-1518837695005-2083093ee35b",
        sleep: "photo-1519681393784-d120267933ba",
        street: "photo-1477959858617-67f85cf4f1df",
        monsoon: "photo-1518837695005-2083093ee35b",
        dhol: "photo-1501386761578-eac5c94b800a",
        mumbai: "photo-1477959858617-67f85cf4f1df",
        sitar: "photo-1500530855697-b586d89ba3ee",
        garba: "photo-1514525253161-7a46d19cd819",
        default: "photo-1506157786151-b8491531f063"
    },
    trend: {
        night: "photo-1477959858617-67f85cf4f1df",
        outfit: "photo-1515886657613-9f3515b0c78f",
        reset: "photo-1495474472287-4d71bcdd2085",
        wins: "photo-1490750967868-88aa4486c946",
        monsoon: "photo-1518837695005-2083093ee35b",
        chai: "photo-1495474472287-4d71bcdd2085",
        saree: "photo-1515886657613-9f3515b0c78f",
        bollywood: "photo-1501386761578-eac5c94b800a",
        festival: "photo-1514525253161-7a46d19cd819",
        street: "photo-1504674900247-0877df9cc836",
        default: "photo-1506157786151-b8491531f063"
    }
};

function getArtworkUrl(type, subject) {
    const normalizedSubject = (subject || "").toLowerCase();
    const artworkSet = artworkImages[type] || artworkImages.audio;
    const keyword = Object.keys(artworkSet)
        .find(key => key !== "default" && normalizedSubject.includes(key));
    const photoId = artworkSet[keyword || "default"];

    return `https://images.unsplash.com/${photoId}?auto=format&fit=crop&w=900&q=80`;
}

function isTikTokHost(hostname) {
    return hostname === "tiktok.com" || hostname.endsWith(".tiktok.com");
}



document.addEventListener("DOMContentLoaded", () => {

    setupNavigation();

    document
        .getElementById("audioForm")
        .addEventListener("submit", saveAudio);

    document
        .getElementById("trendForm")
        .addEventListener("submit", saveTrend);

    document
        .getElementById("usageForm")
        .addEventListener("submit", saveUsage);

    document
        .getElementById("audioSearch")
        .addEventListener("input", renderAudios);

    document
        .getElementById("artistFilter")
        .addEventListener("change", renderAudios);

    document
        .getElementById("audioSort")
        .addEventListener("change", renderAudios);

    document
        .getElementById("audioGrid")
        .addEventListener("click", event => {
            const playButton = event.target.closest(".album-play");
            if (playButton) {
                window.playAudio(playButton.dataset.audioId);
            }
        });

    document
        .getElementById("audioPlayer")
        .addEventListener("error", () => {
            showToast("Could not play this audio. Check the audio file URL.");
        });

    document
        .getElementById("generatedPreviewStop")
        .addEventListener("click", stopGeneratedPreview);

    document
        .getElementById("globalSearch")
        .addEventListener("input", globalSearch);

    if (!firebaseConfigured) {
        setFirebaseStatus(false, "Firebase setup required");
        showToast("Add the Firebase Web App apiKey and appId in frontend/firebase-config.js.");
        return;
    }

    onAuthStateChanged(auth, user => {
        if (!user) {
            window.location.replace("login.html");
            return;
        }

        setupAccountMenu(user);
        loadAllData();
    }, error => {
        console.error("Could not determine Firebase Authentication state.", error);
        showToast("Could not verify your Firebase login.");
    });

});

function setupAccountMenu(user) {
    const profileButton = document.getElementById("profileButton");
    const accountMenu = document.getElementById("accountMenu");
    const logoutButton = document.getElementById("logoutButton");
    const settingsLogoutButton = document.getElementById("settingsLogoutButton");
    const accountLoginLink = document.getElementById("accountLoginLink");
    const settingsLoginLink = document.getElementById("settingsLoginLink");
    const account = {
        name: user.displayName || user.email?.split("@")[0] || "Member",
        email: user.email || "",
        role: "Member"
    };

    function renderAccount() {
        const initials = account.name
            .trim()
            .split(/\s+/)
            .slice(0, 2)
            .map(part => part.charAt(0).toUpperCase())
            .join("") || "OT";

        document.getElementById("profileAvatar").textContent = initials;
        document.getElementById("profileName").textContent = account.name;
        document.getElementById("profileRole").textContent = account.role;
        document.getElementById("accountAvatar").textContent = initials;
        document.getElementById("accountName").textContent = account.name;
        document.getElementById("accountRole").textContent = account.role;
        document.getElementById("accountEmail").textContent = account.email;
        document.getElementById("settingsAccountName").textContent =
            `${account.name} · ${account.role}`;
        document.getElementById("settingsAccountEmail").textContent = account.email;

        logoutButton.hidden = false;
        settingsLogoutButton.hidden = false;
        accountLoginLink.hidden = true;
        settingsLoginLink.hidden = true;
    }

    renderAccount();

    profileButton.addEventListener("click", () => {
        const isOpen = !accountMenu.hidden;
        accountMenu.hidden = isOpen;
        profileButton.setAttribute("aria-expanded", String(!isOpen));
    });

    document.addEventListener("click", event => {
        if (!event.target.closest(".profile-menu")) {
            accountMenu.hidden = true;
            profileButton.setAttribute("aria-expanded", "false");
        }
    });

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            accountMenu.hidden = true;
            profileButton.setAttribute("aria-expanded", "false");
            profileButton.focus();
        }
    });

    const logOut = async () => {
        try {
            await signOut(auth);
            window.location.replace("login.html");
        } catch (error) {
            console.error("Could not sign out from Firebase Authentication.", error);
            showToast("Could not sign out. Please try again.");
        }
    };

    logoutButton.addEventListener("click", logOut);
    settingsLogoutButton.addEventListener("click", logOut);

}



function setupNavigation() {

    const buttons = document.querySelectorAll(".nav-item");

    buttons.forEach(button => {

        button.addEventListener("click", () => {

            const page = button.dataset.page;

            showPage(page);

        });

    });

}


window.showPage = function(pageName) {

    document.querySelectorAll(".page")
        .forEach(page => {

            page.classList.remove("active-page");

        });


    const selectedPage =
        document.getElementById(pageName);

    if (selectedPage) {

        selectedPage.classList.add("active-page");

    }


    document.querySelectorAll(".nav-item")
        .forEach(button => {

            button.classList.remove("active");

            if (button.dataset.page === pageName) {

                button.classList.add("active");

            }

        });


    const titles = {

        dashboard: [
            "Trend Overview",
            "Monitor your audio trends and performance."
        ],

        audio: [
            "Audio Tracks",
            "Manage all audio tracks in the demo dataset."
        ],

        trending: [
            "Trending Now",
            "Discover the most viral audio trends."
        ],

        analytics: [
            "Analytics",
            "Understand your audio trend performance."
        ],

        usage: [
            "Trend Usage",
            "Connect audio tracks with trending topics."
        ],

        settings: [
            "Settings",
            "Project configuration and database information."
        ]

    };


    document.getElementById("pageTitle")
        .textContent = titles[pageName][0];

    document.getElementById("pageSubtitle")
        .textContent = titles[pageName][1];

};


window.openModal = function(id) {

    document
        .getElementById(id)
        .classList.add("show");

};


window.closeModal = function(id) {

    document
        .getElementById(id)
        .classList.remove("show");

    if (id === "audioPlayerModal") {
        const audioPlayer = document.getElementById("audioPlayer");
        const tiktokPlayer = document.getElementById("tiktokPlayer");
        audioPlayer.pause();
        audioPlayer.removeAttribute("src");
        audioPlayer.load();
        tiktokPlayer.removeAttribute("src");
        stopGeneratedPreview();
    }

};


// =====================================================
// LOAD MOCK DATA
// =====================================================

async function loadAllData() {

    try {
        const storedData = localStorage.getItem(MOCK_STORAGE_KEY);
        const localData = storedData
            ? JSON.parse(storedData)
            : createInitialMockData();
        let data;

        try {
            const getTrackerData = httpsCallable(functions, "getTrackerData");
            const result = await getTrackerData();
            data = result.data || localData;
            setFirebaseStatus(true, "Firebase Connected");
        } catch (error) {
            data = localData;
            setFirebaseStatus(false, "Firebase Offline · Local Data");
            console.error("Could not load data from Firebase Cloud Functions.", error);
            showToast("Could not load Firebase data; showing the local backup.");
        }

        const defaults = createInitialMockData();
        audios = Array.isArray(data.audios) ? data.audios : defaults.audios;
        trends = Array.isArray(data.trends) ? data.trends : defaults.trends;
        usages = Array.isArray(data.usages) ? data.usages : defaults.usages;

        if (localStorage.getItem(INDIAN_TRENDS_SEEDED_KEY) !== "true") {
            const existingTrendIds = new Set(trends.map(trend => trend.id));
            const existingUsageIds = new Set(usages.map(usage => usage.id));

            trends.push(
                ...seededIndianTrends.filter(trend => !existingTrendIds.has(trend.id))
            );
            usages.push(
                ...seededIndianUsages.filter(usage =>
                    !existingUsageIds.has(usage.id) &&
                    audios.some(audio => audio.id === usage.audioId)
                )
            );

            const defaultTrendOrder = initialMockData.trends.map(trend => trend.id);
            trends.sort((first, second) => {
                const firstIndex = defaultTrendOrder.indexOf(first.id);
                const secondIndex = defaultTrendOrder.indexOf(second.id);
                const firstOrder = firstIndex === -1 ? Number.MAX_SAFE_INTEGER : firstIndex;
                const secondOrder = secondIndex === -1 ? Number.MAX_SAFE_INTEGER : secondIndex;
                return firstOrder - secondOrder;
            });
        }

        if (localStorage.getItem(INDIAN_AUDIOS_SEEDED_KEY) !== "true") {
            const existingAudioIds = new Set(audios.map(audio => audio.id));
            const existingUsageIds = new Set(usages.map(usage => usage.id));

            audios.push(
                ...seededIndianAudios.filter(audio => !existingAudioIds.has(audio.id))
            );
            usages.push(
                ...seededIndianAudioUsages.filter(usage =>
                    !existingUsageIds.has(usage.id) &&
                    audios.some(audio => audio.id === usage.audioId) &&
                    trends.some(trend => trend.id === usage.trendId)
                )
            );
        }

        const synced = await persistMockData();
        if (!synced) {
            showToast("Firebase write failed; check Realtime Database rules. Data is saved locally.");
        }
        localStorage.setItem(INDIAN_TRENDS_SEEDED_KEY, "true");
        localStorage.setItem(INDIAN_AUDIOS_SEEDED_KEY, "true");
        renderEverything();

    }

    catch (error) {

        console.error(error);

        showToast(
            "Could not load demo data."
        );

    }

}


async function persistMockData() {
    const data = {
        audios,
        trends,
        usages
    };

    localStorage.setItem(MOCK_STORAGE_KEY, JSON.stringify(data));

    try {
        const saveTrackerData = httpsCallable(functions, "saveTrackerData");
        await saveTrackerData(data);
        setFirebaseStatus(true, "Firebase Connected");
        return true;
    } catch (error) {
        setFirebaseStatus(false, "Firebase Offline · Local Data");
        console.error("Could not sync tracker data through Firebase Cloud Functions.", error);
        return false;
    }
}

function setFirebaseStatus(isConnected, message) {
    const status = document.getElementById("firebaseStatusText");
    const settingsStatus = document.getElementById("firebaseSettingsStatus");
    const indicator = document.querySelector(".database-status .status-dot");
    if (status) {
        status.textContent = message;
    }
    if (settingsStatus) {
        settingsStatus.textContent = isConnected ? "Connected" : "Local only";
        settingsStatus.classList.toggle("firebase-offline", !isConnected);
    }
    if (indicator) {
        indicator.classList.toggle("firebase-offline", !isConnected);
    }
}


function createMockId(prefix) {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}


// =====================================================
// RENDER EVERYTHING
// =====================================================

function renderEverything() {

    updateStats();

    renderAudios();

    renderTrending();

    renderUsage();

    renderTopTrending();

    renderActivity();

    populateDropdowns();

    createCharts();

}


// =====================================================
// DASHBOARD STATS
// =====================================================

function updateStats() {

    document.getElementById("totalAudios")
        .textContent = audios.length;


    document.getElementById("totalTrends")
        .textContent = trends.length;


    const totalUsage =
        usages.reduce(
            (sum, item) =>
                sum + Number(item.usageCount || 0),
            0
        );


    document.getElementById("totalUsage")
        .textContent = formatNumber(totalUsage);


    const high =
        usages.filter(
            item => item.viralityScore === "High"
        ).length;


    document.getElementById("highVirality")
        .textContent = high;

}


// =====================================================
// AUDIO
// =====================================================

async function saveAudio(event) {

    event.preventDefault();


    const id =
        document.getElementById("audioId").value;


    const data = {

        title:
            document.getElementById("audioTitle").value.trim(),

        artist:
            document.getElementById("audioArtist").value.trim(),

        duration:
            document.getElementById("audioDuration").value.trim(),

        sourceUrl:
            document.getElementById("audioSourceUrl").value.trim(),

        createdAt: new Date().toISOString()

    };


    try {

        if (id) {
            audios = audios.map(audio =>
                audio.id === id ? { ...audio, ...data } : audio
            );
        }

        else {
            audios.push({ id: createMockId("audio"), ...data });
        }

        const synced = await persistMockData();
        showToast(synced
            ? (id ? "Audio updated in Firebase." : "Audio saved to Firebase.")
            : "Audio saved locally; Firebase sync failed.");

        document
            .getElementById("audioForm")
            .reset();

        document.getElementById("audioId").value = "";
        document.getElementById("audioSourceUrl").value = "";

        document
            .getElementById("audioModalTitle")
            .textContent = "Add Audio Track";


        closeModal("audioModal");

        renderEverything();

    }

    catch (error) {

        console.error(error);

        showToast("Could not save audio.");

    }

}


function renderAudios() {

    const grid =
        document.getElementById("audioGrid");


    let data = [...audios];


    const search =
        document.getElementById("audioSearch")
        ?.value
        .toLowerCase() || "";


    const artist =
        document.getElementById("artistFilter")
        ?.value || "all";


    const sort =
        document.getElementById("audioSort")
        ?.value || "newest";


    data = data.filter(audio => {

        const matchesSearch =
            audio.title
                ?.toLowerCase()
                .includes(search)

            ||

            audio.artist
                ?.toLowerCase()
                .includes(search);


        const matchesArtist =
            artist === "all"
            ||
            audio.artist === artist;


        return matchesSearch && matchesArtist;

    });


    if (sort === "title") {

        data.sort(
            (a, b) =>
                (a.title || "")
                    .localeCompare(b.title || "")
        );

    }


    if (sort === "artist") {

        data.sort(
            (a, b) =>
                (a.artist || "")
                    .localeCompare(b.artist || "")
        );

    }


    if (data.length === 0) {

        grid.innerHTML = `
            <div class="empty-state">
                No audio tracks found.
            </div>
        `;

        return;

    }


    grid.innerHTML = data.map(audio => {

        const usage =
            usages
                .filter(
                    u => u.audioId === audio.id
                )
                .reduce(
                    (sum, u) =>
                        sum + Number(u.usageCount || 0),
                    0
                );


        return `

            <div class="audio-card">

                <div class="album">
                    <img
                        src="${getArtworkUrl("audio", `${audio.title} ${audio.artist}`)}"
                        alt="Cover artwork for ${escapeHtml(audio.title)}"
                        loading="lazy"
                    >
                    <button
                        class="album-play"
                        type="button"
                        data-audio-id="${escapeHtml(audio.id)}"
                        aria-label="Play ${escapeHtml(audio.title)}"
                        title="Play audio preview"
                    >▶</button>
                    <span class="album-duration">${escapeHtml(audio.duration)}</span>
                </div>

                <div class="audio-title-row">
                    <div>
                        <h3>${escapeHtml(audio.title)}</h3>
                        <p>${escapeHtml(audio.artist)}</p>
                    </div>
                    <span class="audio-signal" aria-label="Audio track">♫</span>
                </div>

                <div class="audio-meta">

                    <span>
                        · ${escapeHtml(audio.duration)}
                    </span>

                    <span>
                        🔥 ${formatNumber(usage)} uses
                    </span>

                </div>

                <div class="card-actions">

                    <button
                        class="small-btn"
                        onclick="editAudio('${audio.id}')"
                    >
                        Edit
                    </button>

                    <button
                        class="small-btn delete"
                        onclick="deleteAudio('${audio.id}')"
                    >
                        Delete
                    </button>

                </div>

            </div>
        `;

    }).join("");

}


window.editAudio = function(id) {

    const audio =
        audios.find(a => a.id === id);


    if (!audio) return;


    document.getElementById("audioId").value =
        audio.id;

    document.getElementById("audioTitle").value =
        audio.title || "";

    document.getElementById("audioArtist").value =
        audio.artist || "";

    document.getElementById("audioDuration").value =
        audio.duration || "";

    document.getElementById("audioSourceUrl").value =
        audio.sourceUrl || "";

    document
        .getElementById("audioModalTitle")
        .textContent = "Edit Audio Track";


    openModal("audioModal");

};

window.playAudio = function(id) {
    const audio = audios.find(track => track.id === id);
    if (!audio) {
        showToast("Audio track not found.");
        return;
    }

    const audioPlayer = document.getElementById("audioPlayer");
    const tiktokPlayer = document.getElementById("tiktokPlayer");
    const generatedPreviewControls = document.getElementById("generatedPreviewControls");
    const playerHelp = document.getElementById("playerHelp");
    const description = document.getElementById("audioPlayerDescription");

    stopGeneratedPreview();
    audioPlayer.pause();
    audioPlayer.removeAttribute("src");
    audioPlayer.hidden = true;
    audioPlayer.load();
    tiktokPlayer.removeAttribute("src");
    tiktokPlayer.hidden = true;
    generatedPreviewControls.hidden = true;
    playerHelp.hidden = true;
    document.getElementById("audioPlayerTitle").textContent = audio.title;

    if (!audio.sourceUrl) {
        description.textContent = `Generated demo preview for ${audio.artist} · not the original TikTok sound`;
        generatedPreviewControls.hidden = false;
        openModal("audioPlayerModal");
        startGeneratedPreview(audio.title);
        return;
    }

    let source;
    try {
        source = new URL(audio.sourceUrl);
    } catch {
        showToast("This audio source URL is invalid. Edit the track and check the URL.");
        return;
    }

    if (source.protocol !== "https:" && source.protocol !== "http:") {
        showToast("Audio sources must use a secure HTTP or HTTPS URL.");
        return;
    }

    const isTikTok = isTikTokHost(source.hostname);
    const videoMatch = isTikTok ? source.pathname.match(/\/video\/(\d+)/) : null;

    if (isTikTok) {
        if (!videoMatch) {
            showToast("Use a full TikTok video link, such as tiktok.com/@creator/video/123.");
            return;
        }

        description.textContent = `TikTok audio by ${audio.artist}`;
        tiktokPlayer.src =
            `https://www.tiktok.com/player/v1/${videoMatch[1]}?music_info=1&description=0&autoplay=1`;
        tiktokPlayer.hidden = false;
        playerHelp.hidden = false;
    } else {
        description.textContent = `Audio by ${audio.artist}`;
        audioPlayer.src = source.href;
        audioPlayer.hidden = false;
    }

    openModal("audioPlayerModal");

    if (!isTikTok) {
        audioPlayer.play().catch(() => {
            showToast("Press play in the audio controls to start playback.");
        });
    }
};

async function startGeneratedPreview(title) {
    const AudioContextConstructor = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextConstructor) {
        showToast("Audio previews are not supported by this browser.");
        return;
    }

    const context = new AudioContextConstructor();
    generatedPreviewContext = context;

    try {
        await context.resume();
        if (generatedPreviewContext !== context) {
            await context.close();
            return;
        }

        const master = context.createGain();
        master.gain.value = 0.65;
        master.connect(context.destination);

        const scale = [220, 261.63, 293.66, 329.63, 392, 440, 523.25];
        const variation = Array.from(title).reduce(
            (sum, character) => sum + character.charCodeAt(0),
            0
        ) % scale.length;
        const beatDuration = 60 / 100;
        const startAt = context.currentTime + 0.04;
        const notes = [0, 2, 4, 3, 5, 4, 2, 1];

        for (let beat = 0; beat < 16; beat += 1) {
            const beatAt = startAt + beat * beatDuration;
            const kick = context.createOscillator();
            const kickVolume = context.createGain();
            kick.type = "sine";
            kick.frequency.setValueAtTime(115, beatAt);
            kick.frequency.exponentialRampToValueAtTime(42, beatAt + 0.16);
            kickVolume.gain.setValueAtTime(0.42, beatAt);
            kickVolume.gain.exponentialRampToValueAtTime(0.001, beatAt + 0.2);
            kick.connect(kickVolume);
            kickVolume.connect(master);
            kick.start(beatAt);
            kick.stop(beatAt + 0.21);

            if (beat % 2 === 0) {
                const noteIndex = (notes[Math.floor(beat / 2) % notes.length] + variation) % scale.length;
                const melody = context.createOscillator();
                const melodyVolume = context.createGain();
                const noteAt = beatAt + 0.02;
                melody.type = "triangle";
                melody.frequency.value = scale[noteIndex];
                melodyVolume.gain.setValueAtTime(0.001, noteAt);
                melodyVolume.gain.linearRampToValueAtTime(0.14, noteAt + 0.025);
                melodyVolume.gain.exponentialRampToValueAtTime(0.001, noteAt + 0.27);
                melody.connect(melodyVolume);
                melodyVolume.connect(master);
                melody.start(noteAt);
                melody.stop(noteAt + 0.28);
            }
        }

        generatedPreviewTimer = window.setTimeout(
            stopGeneratedPreview,
            16 * beatDuration * 1000 + 300
        );
    } catch (error) {
        if (generatedPreviewContext === context) {
            generatedPreviewContext = undefined;
        }
        await context.close();
        console.error("Could not start generated audio preview.", error);
        showToast("Could not start audio. Check your browser audio settings.");
    }
}

function stopGeneratedPreview() {
    window.clearTimeout(generatedPreviewTimer);
    generatedPreviewTimer = undefined;

    const context = generatedPreviewContext;
    generatedPreviewContext = undefined;
    if (context && context.state !== "closed") {
        context.close().catch(error => {
            console.error("Could not stop generated audio preview.", error);
        });
    }
}


window.deleteAudio = async function(id) {

    if (!confirm("Delete this audio track?")) {
        return;
    }


    try {

        audios = audios.filter(audio => audio.id !== id);
        usages = usages.filter(usage => usage.audioId !== id);
        const synced = await persistMockData();
        showToast(synced
            ? "Audio deleted from Firebase."
            : "Audio deleted locally; Firebase sync failed.");

        renderEverything();

    }

    catch (error) {

        console.error(error);

        showToast("Could not delete audio.");

    }

};


// =====================================================
// TRENDS
// =====================================================

async function saveTrend(event) {

    event.preventDefault();


    const data = {

        trendName:
            document.getElementById("trendName")
                .value.trim(),

        description:
            document.getElementById("trendDescription")
                .value.trim(),

        peakDate:
            document.getElementById("peakDate")
                .value,

        createdAt:
            new Date().toISOString()

    };


    try {

        trends.push({ id: createMockId("trend"), ...data });
        const synced = await persistMockData();
        showToast(synced
            ? "Trend saved to Firebase."
            : "Trend saved locally; Firebase sync failed.");


        document
            .getElementById("trendForm")
            .reset();


        closeModal("trendModal");

        renderEverything();

    }

    catch (error) {

        console.error(error);

        showToast("Could not save trend.");

    }

}


// =====================================================
// TREND USAGE
// =====================================================

async function saveUsage(event) {

    event.preventDefault();


    const data = {

        audioId:
            document.getElementById("usageAudio")
                .value,

        trendId:
            document.getElementById("usageTrend")
                .value,

        viralityScore:
            document.getElementById("viralityScore")
                .value,

        usageCount:
            Number(
                document.getElementById("usageCount")
                    .value
            ),

        createdAt:
            new Date().toISOString()

    };


    try {

        usages.push({ id: createMockId("usage"), ...data });
        const synced = await persistMockData();
        showToast(synced
            ? "Trend usage saved to Firebase."
            : "Trend usage saved locally; Firebase sync failed.");


        document
            .getElementById("usageForm")
            .reset();


        closeModal("usageModal");

        renderEverything();

    }

    catch (error) {

        console.error(error);

        showToast(
            "Could not save trend usage."
        );

    }

}


// =====================================================
// DROPDOWNS
// =====================================================

function populateDropdowns() {

    const artistFilter =
        document.getElementById("artistFilter");


    const currentArtist =
        artistFilter.value;


    const artists =
        [...new Set(
            audios
                .map(a => a.artist)
                .filter(Boolean)
        )]
        .sort();


    artistFilter.innerHTML =
        `<option value="all">All Artists</option>`;


    artists.forEach(artist => {

        artistFilter.innerHTML += `

            <option value="${escapeHtml(artist)}">
                ${escapeHtml(artist)}
            </option>

        `;

    });


    if (
        artists.includes(currentArtist)
    ) {

        artistFilter.value =
            currentArtist;

    }


    const audioSelect =
        document.getElementById("usageAudio");


    audioSelect.innerHTML =
        `<option value="">Select Audio</option>`;


    audios.forEach(audio => {

        audioSelect.innerHTML += `

            <option value="${audio.id}">
                ${escapeHtml(audio.title)}
                - ${escapeHtml(audio.artist)}
            </option>

        `;

    });


    const trendSelect =
        document.getElementById("usageTrend");


    trendSelect.innerHTML =
        `<option value="">Select Trend</option>`;


    trends.forEach(trend => {

        trendSelect.innerHTML += `

            <option value="${trend.id}">
                ${escapeHtml(trend.trendName)}
            </option>

        `;

    });

}


// =====================================================
// TRENDING
// =====================================================

function renderTrending() {

    const grid =
        document.getElementById("trendingGrid");


    const ranking =
        getTrendCardRanking();


    if (ranking.length === 0) {

        grid.innerHTML = `
            <div class="empty-state">
                No trending audio available yet.
            </div>
        `;

        return;

    }


    grid.innerHTML =
        ranking.map((item, index) => {

            return `

                <div class="trending-card
                    ${index === 0 ? "first" : ""}">

                    <div class="trending-artwork">
                        <img
                            src="${getArtworkUrl("trend", item.trend.trendName)}"
                            alt="${escapeHtml(item.trend.trendName)} trend artwork"
                            loading="lazy"
                        >
                        <span class="trending-number">#${index + 1}</span>
                        <span class="trending-uses">${formatNumber(item.usage)} uses</span>
                    </div>

                    <div class="trending-content">
                        <span class="trending-label">TRENDING AUDIO</span>
                        <h3>${escapeHtml(item.trend.trendName)}</h3>
                        <p>${escapeHtml(item.trend.description || item.audio?.title || "Discover this audio trend")}</p>
                        ${item.audio ? `<span class="trending-track">${escapeHtml(item.audio.title)} · ${escapeHtml(item.audio.artist)}</span>` : ""}

                        <div class="trending-footer">

                            <span class="badge
                                badge-${item.score.toLowerCase()}">

                                ${item.score}

                            </span>

                            <span class="trending-peak">
                                ↗ ${escapeHtml(item.trend.peakDate || "Trending now")}
                            </span>

                        </div>
                    </div>

                </div>

            `;

        }).join("");

}

function getTrendCardRanking() {
    return trends.map(trend => {
        const trendUsages = usages.filter(usage => usage.trendId === trend.id);
        const usage = trendUsages.reduce(
            (total, item) => total + Number(item.usageCount || 0),
            0
        );
        const topUsage = trendUsages.reduce((top, item) =>
            Number(item.usageCount || 0) > Number(top?.usageCount || 0) ? item : top,
        null);
        const audio = audios.find(item => item.id === topUsage?.audioId);
        const score = trendUsages.reduce((highest, item) =>
            scoreValue(item.viralityScore) > scoreValue(highest)
                ? item.viralityScore
                : highest,
        "Low");

        return { trend, audio, usage, score };
    });
}


function getTrendingRanking() {

    const result = [];


    audios.forEach(audio => {

        const audioUsages =
            usages.filter(
                u => u.audioId === audio.id
            );


        if (audioUsages.length === 0) {
            return;
        }


        let usage = 0;

        let score = "Low";
        let topTrendUsage = -1;
        let topTrend = null;


        audioUsages.forEach(u => {

            const usageCount = Number(u.usageCount || 0);
            usage += usageCount;

            if (usageCount > topTrendUsage) {
                topTrendUsage = usageCount;
                topTrend = trends.find(trend => trend.id === u.trendId) || null;
            }


            if (
                scoreValue(u.viralityScore)
                >
                scoreValue(score)
            ) {

                score =
                    u.viralityScore;

            }

        });


        result.push({

            audio,

            usage,
            trend: topTrend,

            score

        });

    });


    result.sort((a, b) => {

        const scoreDifference =
            scoreValue(b.score)
            -
            scoreValue(a.score);


        if (scoreDifference !== 0) {
            return scoreDifference;
        }


        return b.usage - a.usage;

    });


    return result;

}


function scoreValue(score) {

    if (score === "High") return 3;

    if (score === "Medium") return 2;

    return 1;

}


// =====================================================
// TOP TRENDING
// =====================================================

function renderTopTrending() {

    const container =
        document.getElementById("topTrendingList");


    const ranking =
        getTrendingRanking().slice(0, 5);


    if (ranking.length === 0) {

        container.innerHTML = `
            <div class="empty-state">
                No trending data yet.
            </div>
        `;

        return;

    }


    container.innerHTML =
        ranking.map((item, index) => {

            return `

                <div class="trend-row">

                    <img
                        class="trend-thumb"
                        src="${getArtworkUrl("audio", `${item.audio.title} ${item.audio.artist}`)}"
                        alt=""
                        loading="lazy"
                    >

                    <div class="rank">
                        ${index + 1}
                    </div>

                    <div class="track-info">

                        <strong>
                            ${escapeHtml(item.audio.title)}
                        </strong>

                        <small>
                            ${escapeHtml(item.audio.artist)}
                        </small>

                    </div>

                    <span class="badge
                        badge-${item.score.toLowerCase()}">

                        ${item.score}

                    </span>

                    <div class="usage-number">
                        <span>${formatNumber(item.usage)}</span>
                        <small>uses</small>
                    </div>

                </div>

            `;

        }).join("");

}


// =====================================================
// USAGE TABLE
// =====================================================

function renderUsage() {

    const table =
        document.getElementById("usageTable");


    if (usages.length === 0) {

        table.innerHTML = `

            <tr>
                <td colspan="5">

                    <div class="empty-state">
                        No usage records yet.
                    </div>

                </td>
            </tr>

        `;

        return;

    }


    table.innerHTML =
        usages.map(usage => {

            const audio =
                audios.find(
                    a => a.id === usage.audioId
                );


            const trend =
                trends.find(
                    t => t.id === usage.trendId
                );


            return `

                <tr>

                    <td>

                        <strong>
                            ${escapeHtml(
                                audio?.title || "Unknown"
                            )}
                        </strong>

                        <small>
                            ${escapeHtml(
                                audio?.artist || ""
                            )}
                        </small>

                    </td>

                    <td>
                        ${escapeHtml(
                            trend?.trendName || "Unknown"
                        )}
                    </td>

                    <td>

                        <span class="badge
                            badge-${(
                                usage.viralityScore || "Low"
                            ).toLowerCase()}">

                            ${escapeHtml(
                                usage.viralityScore || "Low"
                            )}

                        </span>

                    </td>

                    <td>
                        ${formatNumber(
                            usage.usageCount || 0
                        )}
                    </td>

                    <td>

                        <button
                            class="small-btn delete"
                            onclick="deleteUsage('${usage.id}')"
                        >
                            Delete
                        </button>

                    </td>

                </tr>

            `;

        }).join("");

}


window.deleteUsage = async function(id) {

    if (!confirm("Delete this usage record?")) {
        return;
    }


    try {

        usages = usages.filter(usage => usage.id !== id);
        const synced = await persistMockData();
        showToast(synced
            ? "Usage record deleted from Firebase."
            : "Usage record deleted locally; Firebase sync failed.");


        renderEverything();

    }

    catch (error) {

        console.error(error);

        showToast(
            "Could not delete record."
        );

    }

};


// =====================================================
// RECENT ACTIVITY
// =====================================================

function renderActivity() {

    const container =
        document.getElementById("activityList");


    const recent =
        [...usages]
            .reverse()
            .slice(0, 5);


    if (recent.length === 0) {

        container.innerHTML = `
            <div class="empty-state">
                No recent activity.
            </div>
        `;

        return;

    }


    container.innerHTML =
        recent.map(item => {

            const audio =
                audios.find(
                    a => a.id === item.audioId
                );


            const trend =
                trends.find(
                    t => t.id === item.trendId
                );


            return `

                <div class="activity-item">

                    <div class="activity-icon">
                        🔥
                    </div>

                    <div>

                        <strong>
                            ${escapeHtml(
                                audio?.title || "Audio"
                            )}
                        </strong>

                        <p>
                            Added to
                            ${escapeHtml(
                                trend?.trendName || "trend"
                            )}
                            •
                            ${escapeHtml(
                                item.viralityScore || "Low"
                            )}
                        </p>

                    </div>

                </div>

            `;

        }).join("");

}


// =====================================================
// CHARTS
// =====================================================

function createCharts() {

    Chart.defaults.color = "#64746A";
    Chart.defaults.font.family = "Inter, Segoe UI, Arial, sans-serif";
    Chart.defaults.plugins.tooltip.backgroundColor = "#104B3B";
    Chart.defaults.plugins.tooltip.titleColor = "#FFFFFF";
    Chart.defaults.plugins.tooltip.bodyColor = "#FFFFFF";
    Chart.defaults.plugins.tooltip.borderColor = "#B7CDB5";
    Chart.defaults.plugins.tooltip.borderWidth = 1;
    Chart.defaults.plugins.tooltip.padding = 11;
    Chart.defaults.plugins.tooltip.cornerRadius = 9;

    createAudioChart();

    createViralityChart();

    createAnalyticsChart();

    createTrendChart();

}


function createAudioChart() {

    const canvas =
        document.getElementById("audioChart");


    if (audioChart) {
        audioChart.destroy();
    }


    const ranking =
        getTrendingRanking().slice(0, 7);


    audioChart =
        new Chart(canvas, {

            type: "bar",

            data: {

                labels:
                    ranking.map(
                        x => x.audio.title
                    ),

                datasets: [{

                    label: "Usage",

                    data:
                        ranking.map(
                            x => x.usage
                        ),

                    borderRadius: 8,

                    backgroundColor: [
                        "#104B3B",
                        "#176B52",
                        "#4D8A6D",
                        "#B7CDB5",
                        "#78977D",
                        "#E5EDE2",
                        "#2D8064"
                    ]

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                plugins: {

                    legend: {
                        display: false
                    }

                },

                scales: {

                    x: {
                        ticks: {
                            color: "#526357"
                        },

                        grid: {
                            display: false
                        }
                    },

                    y: {
                        ticks: {
                            color: "#526357"
                        },

                        grid: {
                        color: "#E5EDE2"
                        }
                    }

                }

            }

        });

}


function createViralityChart() {

    const canvas =
        document.getElementById("viralityChart");


    if (viralityChart) {
        viralityChart.destroy();
    }


    const high =
        usages.filter(
            x => x.viralityScore === "High"
        ).length;


    const medium =
        usages.filter(
            x => x.viralityScore === "Medium"
        ).length;


    const low =
        usages.filter(
            x => x.viralityScore === "Low"
        ).length;


    document.getElementById("highLegend")
        .textContent = high;

    document.getElementById("mediumLegend")
        .textContent = medium;

    document.getElementById("lowLegend")
        .textContent = low;


    viralityChart =
        new Chart(canvas, {

            type: "doughnut",

            data: {

                labels: [
                    "High",
                    "Medium",
                    "Low"
                ],

                datasets: [{

                    data: [
                        high,
                        medium,
                        low
                    ],

                    backgroundColor: [
                        "#176B52",
                        "#8EAF94",
                        "#DCE7D9"
                    ],

                    borderWidth: 0

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                cutout: "70%",

                plugins: {

                    legend: {
                        display: false
                    }

                }

            }

        });

}


function createAnalyticsChart() {

    const canvas =
        document.getElementById(
            "analyticsBarChart"
        );


    if (analyticsBarChart) {
        analyticsBarChart.destroy();
    }


    const ranking =
        getTrendingRanking().slice(0, 10);


    analyticsBarChart =
        new Chart(canvas, {

            type: "bar",

            data: {

                labels:
                    ranking.map(
                        x => x.audio.title
                    ),

                datasets: [{

                    label: "Usage",

                    data:
                        ranking.map(
                            x => x.usage
                        ),

                    backgroundColor: [
                        "#104B3B",
                        "#176B52",
                        "#4D8A6D",
                        "#B7CDB5",
                        "#78977D",
                        "#E5EDE2",
                        "#2D8064",
                        "#9BB99D",
                        "#6F9478",
                        "#C7D8C4"
                    ],

                    borderRadius: 7

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                scales: {

                    x: {

                        ticks: {
                            color: "#526357"
                        },

                        grid: {
                            display: false
                        }

                    },

                    y: {

                        ticks: {
                            color: "#526357"
                        },

                        grid: {
                            color: "#E5EDE2"
                        }

                    }

                }

            }

        });

}


function createTrendChart() {

    const canvas =
        document.getElementById(
            "trendChart"
        );


    if (trendChart) {
        trendChart.destroy();
    }


    const trendData = trends.map(trend => {

        const total =
            usages
                .filter(
                    u => u.trendId === trend.id
                )
                .reduce(
                    (sum, u) =>
                        sum + Number(
                            u.usageCount || 0
                        ),
                    0
                );


        return {

            name: trend.trendName,

            total

        };

    });


    trendChart =
        new Chart(canvas, {

            type: "line",

            data: {

                labels:
                    trendData.map(
                        x => x.name
                    ),

                datasets: [{

                    label: "Trend Usage",

                    data:
                        trendData.map(
                            x => x.total
                        ),

                    borderColor:
                        "#176B52",

                    backgroundColor:
                        "rgba(23,107,82,.12)",

                    fill: true,

                    tension: .4

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                scales: {

                    x: {

                        ticks: {
                            color: "#526357"
                        },

                        grid: {
                            display: false
                        }

                    },

                    y: {

                        ticks: {
                            color: "#526357"
                        },

                        grid: {
                            color: "#E5EDE2"
                        }

                    }

                }

            }

        });

}


// =====================================================
// SEARCH
// =====================================================

function globalSearch(event) {

    const value =
        event.target.value.trim();


    if (value.length > 0) {

        showPage("audio");

        document.getElementById(
            "audioSearch"
        ).value = value;

        renderAudios();

    }

}


// =====================================================
// UTILITIES
// =====================================================

function formatNumber(number) {

    return Number(number || 0)
        .toLocaleString("en-IN");

}


function escapeHtml(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


function showToast(message) {

    const toast =
        document.getElementById("toast");

    document.getElementById(
        "toastMessage"
    ).textContent = message;


    toast.classList.add("show");


    setTimeout(() => {

        toast.classList.remove("show");

    }, 2500);

}
