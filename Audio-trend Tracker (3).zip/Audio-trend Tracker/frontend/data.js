export const TRACKER_STORAGE_KEY = "audioTrendMockData";

const initialMockData = {
    audios: [
        { id: "audio-1", title: "Midnight Signal", artist: "Nova June", duration: "0:28" },
        { id: "audio-2", title: "Velvet Static", artist: "The Glass Hours", duration: "0:19" },
        { id: "audio-3", title: "Golden Hour Loop", artist: "Milo North", duration: "0:32" },
        { id: "audio-4", title: "No Sleep in June", artist: "Arden Blue", duration: "0:24" },
        { id: "audio-5", title: "Soft Focus", artist: "Luna Parke", duration: "0:16" },
        { id: "audio-6", title: "After the Rain", artist: "Common Weather", duration: "0:31" },
        { id: "audio-7", title: "Side Street", artist: "Jules Avery", duration: "0:22" },
        { id: "audio-in-1", title: "Monsoon Chai Lo-fi", artist: "Raga Rain", duration: "0:27" },
        { id: "audio-in-2", title: "Dhol Beat Bounce", artist: "Jaipur Beats", duration: "0:24" },
        { id: "audio-in-3", title: "Mumbai Local Rush", artist: "City Raga", duration: "0:21" },
        { id: "audio-in-4", title: "Sitar Sunset", artist: "Anaya Sounds", duration: "0:32" },
        { id: "audio-in-5", title: "Garba Glow", artist: "Navratri Nights", duration: "0:26" }
    ],
    trends: [
        { id: "trend-1", trendName: "Sunday Reset", description: "Slow morning routines and weekly resets", peakDate: "2026-09-28" },
        { id: "trend-in-1", trendName: "Monsoon Chai Moments", description: "Rainy-day chai, cozy windows, and monsoon playlists", peakDate: "2026-10-06" },
        { id: "trend-2", trendName: "Night Drive", description: "Late-night city and road clips", peakDate: "2026-10-02" },
        { id: "trend-in-2", trendName: "Saree Spin Transition", description: "A quick turn that reveals a festive saree look", peakDate: "2026-10-07" },
        { id: "trend-3", trendName: "Little Wins", description: "Small everyday moments worth celebrating", peakDate: "2026-10-04" },
        { id: "trend-in-3", trendName: "Bollywood Hookstep Replay", description: "Recreating a catchy hookstep with friends", peakDate: "2026-10-08" },
        { id: "trend-in-4", trendName: "Festival Fit Check", description: "Showing off colorful looks before heading to a celebration", peakDate: "2026-10-09" },
        { id: "trend-4", trendName: "Outfit Transition", description: "Quick-cut style transformations", peakDate: "2026-10-05" },
        { id: "trend-in-5", trendName: "Street Food Sizzle", description: "Close-up clips of favorite Indian street-food bites", peakDate: "2026-10-10" }
    ],
    usages: [
        { id: "usage-1", audioId: "audio-1", trendId: "trend-2", viralityScore: "High", usageCount: 18400 },
        { id: "usage-in-1", audioId: "audio-6", trendId: "trend-in-1", viralityScore: "Medium", usageCount: 6800 },
        { id: "usage-2", audioId: "audio-2", trendId: "trend-4", viralityScore: "High", usageCount: 12750 },
        { id: "usage-in-2", audioId: "audio-5", trendId: "trend-in-2", viralityScore: "High", usageCount: 14300 },
        { id: "usage-3", audioId: "audio-3", trendId: "trend-1", viralityScore: "Medium", usageCount: 9300 },
        { id: "usage-in-3", audioId: "audio-4", trendId: "trend-in-3", viralityScore: "High", usageCount: 16500 },
        { id: "usage-4", audioId: "audio-4", trendId: "trend-2", viralityScore: "High", usageCount: 22100 },
        { id: "usage-5", audioId: "audio-5", trendId: "trend-3", viralityScore: "Medium", usageCount: 7100 },
        { id: "usage-in-4", audioId: "audio-2", trendId: "trend-in-4", viralityScore: "Medium", usageCount: 9200 },
        { id: "usage-6", audioId: "audio-6", trendId: "trend-1", viralityScore: "Low", usageCount: 3600 },
        { id: "usage-7", audioId: "audio-7", trendId: "trend-3", viralityScore: "Medium", usageCount: 8450 },
        { id: "usage-in-5", audioId: "audio-7", trendId: "trend-in-5", viralityScore: "High", usageCount: 11200 },
        { id: "usage-8", audioId: "audio-1", trendId: "trend-3", viralityScore: "Medium", usageCount: 5200 },
        { id: "usage-9", audioId: "audio-3", trendId: "trend-4", viralityScore: "Low", usageCount: 2900 },
        { id: "usage-audio-in-1", audioId: "audio-in-1", trendId: "trend-in-1", viralityScore: "High", usageCount: 15800 },
        { id: "usage-audio-in-2", audioId: "audio-in-2", trendId: "trend-in-3", viralityScore: "High", usageCount: 19600 },
        { id: "usage-audio-in-3", audioId: "audio-in-3", trendId: "trend-in-5", viralityScore: "Medium", usageCount: 10400 },
        { id: "usage-audio-in-4", audioId: "audio-in-4", trendId: "trend-in-2", viralityScore: "Medium", usageCount: 8700 },
        { id: "usage-audio-in-5", audioId: "audio-in-5", trendId: "trend-in-4", viralityScore: "High", usageCount: 17200 }
    ]
};

export function createInitialMockData() {
    return {
        audios: initialMockData.audios.map(audio => ({ ...audio })),
        trends: initialMockData.trends.map(trend => ({ ...trend })),
        usages: initialMockData.usages.map(usage => ({ ...usage }))
    };
}
