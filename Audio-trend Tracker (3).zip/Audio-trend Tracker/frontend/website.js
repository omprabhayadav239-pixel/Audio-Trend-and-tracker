import { createInitialMockData, TRACKER_STORAGE_KEY } from "./data.js";

const numberFormatter = new Intl.NumberFormat("en-IN");
const seededTrendsKey = "audioTrendIndianTrendsSeeded";
const seededAudiosKey = "audioTrendIndianAudiosSeeded";
const viralityLevels = ["High", "Medium", "Low"];
const chartColors = ["#176B52", "#B7CDB5", "#E5EDE2"];
const artworkImages = {
    audio: {
        night: "photo-1519608487953-e999c86e7455",
        gold: "photo-1490750967868-88aa4486c946",
        velvet: "photo-1516280440614-37939bbacd81",
        rain: "photo-1518837695005-2083093ee35b",
        sleep: "photo-1519681393784-d120267933ba",
        street: "photo-1477959858617-67f85cf4f1df",
        monsoon: "photo-1518837695005-2083093ee35b",
        dhol: "photo-1501386761578-eac5c94b800a",
        mumbai: "photo-1477959858617-67f85cf4f1df",
        sitar: "photo-1500530855697-b586d89ba3ee",
        garba: "photo-1514525253161-7a46d19cd819",
        default: "photo-1506157786151-b8491531f063"
    },
    trend: {
        night: "photo-1477959858617-67f85cf4f1df",
        outfit: "photo-1515886657613-9f3515b0c78f",
        reset: "photo-1495474472287-4d71bcdd2085",
        wins: "photo-1490750967868-88aa4486c946",
        monsoon: "photo-1518837695005-2083093ee35b",
        chai: "photo-1495474472287-4d71bcdd2085",
        saree: "photo-1515886657613-9f3515b0c78f",
        bollywood: "photo-1501386761578-eac5c94b800a",
        festival: "photo-1514525253161-7a46d19cd819",
        street: "photo-1504674900247-0877df9cc836",
        default: "photo-1506157786151-b8491531f063"
    }
};

let dashboardData;

document.addEventListener("DOMContentLoaded", () => {
    bindControls();
    refreshDashboardData();

    window.addEventListener("storage", event => {
        if (event.key === TRACKER_STORAGE_KEY || event.key === null) {
            refreshDashboardData();
        }
    });

    window.addEventListener("focus", refreshDashboardData);
    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible") {
            refreshDashboardData();
        }
    });
});

function bindControls() {
    document.getElementById("globalSearch").addEventListener("input", renderRecords);
    document.getElementById("audioSearch").addEventListener("input", renderAudioCards);
    document.getElementById("artistFilter").addEventListener("change", renderAudioCards);
    document.getElementById("audioSort").addEventListener("change", renderAudioCards);
    document.getElementById("trendViralityFilter").addEventListener("change", renderTrendCards);
    document.getElementById("usageSearch").addEventListener("input", renderUsageTable);
    document.getElementById("usageViralityFilter").addEventListener("change", renderUsageTable);

    const menuToggle = document.getElementById("menuToggle");
    const navigation = document.getElementById("primaryNavigation");
    menuToggle.addEventListener("click", () => {
        const isOpen = menuToggle.getAttribute("aria-expanded") === "true";
        menuToggle.setAttribute("aria-expanded", String(!isOpen));
        menuToggle.setAttribute("aria-label", isOpen ? "Open navigation" : "Close navigation");
        navigation.classList.toggle("is-open", !isOpen);
    });

    navigation.addEventListener("click", event => {
        if (event.target.closest("a")) {
            navigation.classList.remove("is-open");
            menuToggle.setAttribute("aria-expanded", "false");
            menuToggle.setAttribute("aria-label", "Open navigation");
        }
    });
}

function refreshDashboardData() {
    try {
        dashboardData = readDashboardData();
        document.getElementById("dataError").hidden = true;
        populateArtistFilter();
        renderDashboard();
    } catch (error) {
        console.error("Could not read the dashboard data.", error);
        const notice = document.getElementById("dataError");
        notice.textContent = `Dashboard data could not be loaded: ${error.message}`;
        notice.hidden = false;
        clearRenderedData();
    }
}

function readDashboardData() {
    const stored = window.localStorage.getItem(TRACKER_STORAGE_KEY);
    if (!stored) {
        return createInitialMockData();
    }

    const parsed = JSON.parse(stored);
    if (
        !parsed ||
        !Array.isArray(parsed.audios) ||
        !Array.isArray(parsed.trends) ||
        !Array.isArray(parsed.usages)
    ) {
        throw new Error("The shared audio, trend, or usage records are missing.");
    }

    return mergeDashboardSeeds(parsed);
}

function mergeDashboardSeeds(parsed) {
    const data = {
        audios: parsed.audios.map(audio => ({ ...audio })),
        trends: parsed.trends.map(trend => ({ ...trend })),
        usages: parsed.usages.map(usage => ({ ...usage }))
    };
    const defaults = createInitialMockData();
    const seededTrends = defaults.trends.filter(trend => trend.id.startsWith("trend-in-"));
    const seededTrendUsages = defaults.usages.filter(usage => usage.id.startsWith("usage-in-"));
    const seededAudios = defaults.audios.filter(audio => audio.id.startsWith("audio-in-"));
    const seededAudioUsages = defaults.usages.filter(usage => usage.id.startsWith("usage-audio-in-"));

    if (window.localStorage.getItem(seededTrendsKey) !== "true") {
        const existingTrendIds = new Set(data.trends.map(trend => trend.id));
        const existingUsageIds = new Set(data.usages.map(usage => usage.id));
        data.trends.push(...seededTrends.filter(trend => !existingTrendIds.has(trend.id)));
        data.usages.push(...seededTrendUsages.filter(usage =>
            !existingUsageIds.has(usage.id) &&
            data.audios.some(audio => audio.id === usage.audioId)
        ));

        const defaultTrendOrder = defaults.trends.map(trend => trend.id);
        data.trends.sort((first, second) => {
            const firstIndex = defaultTrendOrder.indexOf(first.id);
            const secondIndex = defaultTrendOrder.indexOf(second.id);
            const firstOrder = firstIndex === -1 ? Number.MAX_SAFE_INTEGER : firstIndex;
            const secondOrder = secondIndex === -1 ? Number.MAX_SAFE_INTEGER : secondIndex;
            return firstOrder - secondOrder;
        });
    }

    if (window.localStorage.getItem(seededAudiosKey) !== "true") {
        const existingAudioIds = new Set(data.audios.map(audio => audio.id));
        const existingUsageIds = new Set(data.usages.map(usage => usage.id));
        data.audios.push(...seededAudios.filter(audio => !existingAudioIds.has(audio.id)));
        data.usages.push(...seededAudioUsages.filter(usage =>
            !existingUsageIds.has(usage.id) &&
            data.audios.some(audio => audio.id === usage.audioId) &&
            data.trends.some(trend => trend.id === usage.trendId)
        ));
    }

    return data;
}

function clearRenderedData() {
    ["audioGrid", "trendingGrid"].forEach(id => {
        document.getElementById(id).replaceChildren();
    });
    document.getElementById("usageTable").replaceChildren();
    ["totalAudios", "totalTrends", "totalUsage", "highVirality"].forEach(id => {
        document.getElementById(id).textContent = "—";
    });
    renderCharts(null);
}

function renderDashboard() {
    updateStats();
    renderRecords();
    renderCharts(dashboardData);
}

function renderRecords() {
    renderAudioCards();
    renderTrendCards();
    renderUsageTable();
}

function updateStats() {
    const { audios, trends, usages } = dashboardData;
    const totalUsage = usages.reduce(
        (sum, usage) => sum + Number(usage.usageCount || 0),
        0
    );
    const highVirality = usages.filter(usage => usage.viralityScore === "High").length;

    document.getElementById("totalAudios").textContent = formatNumber(audios.length);
    document.getElementById("totalTrends").textContent = formatNumber(trends.length);
    document.getElementById("totalUsage").textContent = formatNumber(totalUsage);
    document.getElementById("highVirality").textContent = formatNumber(highVirality);
}

function populateArtistFilter() {
    const filter = document.getElementById("artistFilter");
    const selectedArtist = filter.value || "all";
    const artists = [...new Set(
        dashboardData.audios.map(audio => audio.artist).filter(Boolean)
    )].sort((first, second) => first.localeCompare(second));

    filter.replaceChildren(new Option("All Artists", "all"));
    artists.forEach(artist => filter.add(new Option(artist, artist)));
    filter.value = artists.includes(selectedArtist) ? selectedArtist : "all";
}

function renderAudioCards() {
    const grid = document.getElementById("audioGrid");
    const globalQuery = normalize(document.getElementById("globalSearch").value);
    const audioQuery = normalize(document.getElementById("audioSearch").value);
    const selectedArtist = document.getElementById("artistFilter").value;
    const sort = document.getElementById("audioSort").value;

    let audios = dashboardData.audios.filter(audio => {
        const text = `${audio.title || ""} ${audio.artist || ""}`.toLowerCase();
        return (
            text.includes(globalQuery) &&
            text.includes(audioQuery) &&
            (selectedArtist === "all" || audio.artist === selectedArtist)
        );
    });

    if (sort === "title") {
        audios = [...audios].sort((first, second) =>
            (first.title || "").localeCompare(second.title || "")
        );
    } else if (sort === "artist") {
        audios = [...audios].sort((first, second) =>
            (first.artist || "").localeCompare(second.artist || "")
        );
    }

    grid.replaceChildren();
    if (audios.length === 0) {
        grid.append(createEmptyState(
            dashboardData.audios.length ? "No audio tracks found." : "No audio tracks added yet."
        ));
        return;
    }

    audios.forEach(audio => {
        const card = document.createElement("article");
        card.className = "audio-card";

        const artwork = createArtwork(
            "audio",
            `${audio.title || ""} ${audio.artist || ""}`,
            `Cover artwork for ${audio.title || ""}`,
            "audio-art"
        );
        if (audio.duration) {
            const duration = createTextElement("span", "art-duration", audio.duration);
            artwork.append(duration);
        }

        const info = createElement("div", "audio-info");
        info.append(
            createTextElement("h3", "", audio.title || ""),
            createTextElement("p", "audio-artist", audio.artist || "")
        );

        const description = getAudioDescription(audio);
        if (description) {
            info.append(createTextElement("p", "audio-description", description));
        }

        const usage = getAudioUsage(audio.id);
        const meta = createElement("div", "audio-meta");
        meta.append(createTextElement("span", "audio-usage", `${formatNumber(usage)} uses`));

        card.append(artwork, info, meta);
        grid.append(card);
    });
}

function renderTrendCards() {
    const grid = document.getElementById("trendingGrid");
    const globalQuery = normalize(document.getElementById("globalSearch").value);
    const selectedVirality = document.getElementById("trendViralityFilter").value;
    const trends = getTrendCardRanking().filter(item => {
        const searchable = [
            item.trend.trendName,
            item.trend.description,
            item.audio?.title,
            item.audio?.artist
        ].join(" ").toLowerCase();

        return searchable.includes(globalQuery) &&
            (selectedVirality === "all" || item.score === selectedVirality);
    });

    grid.replaceChildren();
    if (trends.length === 0) {
        grid.append(createEmptyState(
            dashboardData.trends.length ? "No trending audio found." : "No trending audio available yet."
        ));
        return;
    }

    trends.forEach((item, index) => {
        const card = createElement("article", "trending-card");
        const artwork = createArtwork(
            "trend",
            item.trend.trendName,
            `${item.trend.trendName} trend artwork`,
            "trending-artwork"
        );
        artwork.append(
            createTextElement("span", "trending-number", `#${index + 1}`),
            createTextElement("span", "trending-uses", `${formatNumber(item.usage)} uses`)
        );

        const content = createElement("div", "trending-content");
        content.append(
            createTextElement("span", "trending-label", "TRENDING AUDIO"),
            createTextElement("h3", "", item.trend.trendName || "")
        );
        content.append(createTextElement(
            "p",
            "",
            item.trend.description || item.audio?.title || "Discover this audio trend"
        ));

        if (item.audio) {
            content.append(createTextElement(
                "span",
                "trending-track",
                `${item.audio.title} · ${item.audio.artist}`
            ));
        } else {
            content.append(createTextElement("span", "trending-track", ""));
        }

        const footer = createElement("div", "trending-footer");
        footer.append(
            createViralityBadge(item.score),
            createTextElement("span", "trending-peak", `↗ ${item.trend.peakDate || "Trending now"}`)
        );
        content.append(footer);
        card.append(artwork, content);
        grid.append(card);
    });
}

function renderUsageTable() {
    const table = document.getElementById("usageTable");
    const globalQuery = normalize(document.getElementById("globalSearch").value);
    const localQuery = normalize(document.getElementById("usageSearch").value);
    const selectedVirality = document.getElementById("usageViralityFilter").value;
    const rows = dashboardData.usages.filter(usage => {
        const audio = dashboardData.audios.find(item => item.id === usage.audioId);
        const trend = dashboardData.trends.find(item => item.id === usage.trendId);
        const searchable = [
            audio?.title,
            audio?.artist,
            trend?.trendName,
            usage.viralityScore,
            usage.usageCount
        ].join(" ").toLowerCase();

        return searchable.includes(globalQuery) &&
            searchable.includes(localQuery) &&
            (selectedVirality === "all" || usage.viralityScore === selectedVirality);
    });

    table.replaceChildren();
    if (rows.length === 0) {
        const row = document.createElement("tr");
        const cell = createTextElement(
            "td",
            "table-empty",
            dashboardData.usages.length ? "No usage records found." : "No usage records yet."
        );
        cell.colSpan = 4;
        row.append(cell);
        table.append(row);
        return;
    }

    rows.forEach(usage => {
        const audio = dashboardData.audios.find(item => item.id === usage.audioId);
        const trend = dashboardData.trends.find(item => item.id === usage.trendId);
        const row = document.createElement("tr");
        const audioCell = createElement("td", "audio-cell");
        audioCell.append(
            createTextElement("strong", "", audio?.title || "Unknown"),
            createTextElement("small", "", audio?.artist || "")
        );

        const trendCell = createTextElement("td", "", trend?.trendName || "Unknown");
        const viralityCell = document.createElement("td");
        viralityCell.append(createViralityBadge(usage.viralityScore || "Low"));
        const countCell = createTextElement(
            "td",
            "usage-count-cell",
            formatNumber(usage.usageCount || 0)
        );

        row.append(audioCell, trendCell, viralityCell, countCell);
        table.append(row);
    });
}

function renderCharts(data) {
    const chartIds = ["audioChart", "viralityChart", "trendChart"];
    chartIds.forEach(id => {
        const canvas = document.getElementById(id);
        const existingChart = window.Chart?.getChart(canvas);
        if (existingChart) {
            existingChart.destroy();
        }
    });

    if (!window.Chart) {
        chartIds.forEach(id => {
            showChartMessage(id, "Charts could not load. Check your connection and reload the page.");
        });
        return;
    }

    Chart.defaults.font.family = 'Inter, "Segoe UI", Arial, sans-serif';
    Chart.defaults.color = "#B7CDB5";

    if (!data || data.usages.length === 0) {
        chartIds.forEach(id => showChartMessage(id, "No usage records yet."));
        renderViralityLegend();
        return;
    }

    const rankedAudios = getTrendingRanking(data).slice(0, 7);
    if (rankedAudios.length > 0) {
        showChartCanvas("audioChart");
        new Chart(document.getElementById("audioChart"), {
            type: "bar",
            data: {
                labels: rankedAudios.map(item => item.audio.title),
                datasets: [{
                    label: "Usage",
                    data: rankedAudios.map(item => item.usage),
                    backgroundColor: rankedAudios.map((_, index) =>
                        ["#176B52", "#B7CDB5", "#104B3B", "#E5EDE2", "#176B52", "#B7CDB5", "#104B3B"][index % 7]
                    ),
                    borderRadius: 9,
                    borderSkipped: false,
                    maxBarThickness: 44
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: "#18231D",
                        titleColor: "#E5EDE2",
                        bodyColor: "#B7CDB5",
                        borderColor: "rgba(183, 205, 181, .2)",
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: context => `Usage: ${formatNumber(context.parsed.y)}`
                        }
                    }
                },
                scales: chartScales(32)
            }
        });
    } else {
        showChartMessage("audioChart", "No audio tracks added yet.");
    }

    const counts = viralityLevels.map(level =>
        data.usages.filter(usage => usage.viralityScore === level).length
    );
    showChartCanvas("viralityChart");
    new Chart(document.getElementById("viralityChart"), {
        type: "doughnut",
        data: {
            labels: viralityLevels,
            datasets: [{
                data: counts,
                backgroundColor: chartColors,
                borderColor: "#18231D",
                borderWidth: 4,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "70%",
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: "#18231D",
                    titleColor: "#E5EDE2",
                    bodyColor: "#B7CDB5",
                    borderColor: "rgba(183, 205, 181, .2)",
                    borderWidth: 1,
                    padding: 12,
                    callbacks: {
                        label: context => `${context.label}: ${formatNumber(context.parsed)}`
                    }
                }
            }
        }
    });
    renderViralityLegend();

    const trendTotals = data.trends.map(trend => ({
        trend,
        usage: data.usages
            .filter(usage => usage.trendId === trend.id)
            .reduce((sum, usage) => sum + Number(usage.usageCount || 0), 0)
    }));

    if (trendTotals.length > 0) {
        showChartCanvas("trendChart");
        new Chart(document.getElementById("trendChart"), {
            type: "line",
            data: {
                labels: trendTotals.map(item => item.trend.trendName),
                datasets: [{
                    label: "Trend Usage",
                    data: trendTotals.map(item => item.usage),
                    borderColor: "#176B52",
                    backgroundColor: "rgba(23, 107, 82, .2)",
                    pointBackgroundColor: "#B7CDB5",
                    pointBorderColor: "#18231D",
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    fill: true,
                    tension: .36
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: "#18231D",
                        titleColor: "#E5EDE2",
                        bodyColor: "#B7CDB5",
                        borderColor: "rgba(183, 205, 181, .2)",
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: context => `Trend Usage: ${formatNumber(context.parsed.y)}`
                        }
                    }
                },
                scales: chartScales(36)
            }
        });
    } else {
        showChartMessage("trendChart", "No trends available yet.");
    }
}

function chartScales(rotation) {
    return {
        x: {
            ticks: { color: "#9BAC9F", maxRotation: rotation, minRotation: 0 },
            grid: { display: false }
        },
        y: {
            beginAtZero: true,
            ticks: { color: "#9BAC9F" },
            grid: { color: "rgba(183, 205, 181, .1)" },
            border: { color: "rgba(183, 205, 181, .16)" }
        }
    };
}

function showChartCanvas(id) {
    const canvas = document.getElementById(id);
    canvas.hidden = false;
    const message = canvas.parentElement.querySelector(".chart-message");
    if (message) {
        message.remove();
    }
}

function showChartMessage(id, text) {
    const canvas = document.getElementById(id);
    canvas.hidden = true;
    let message = canvas.parentElement.querySelector(".chart-message");
    if (!message) {
        message = createElement("div", "chart-message");
        canvas.parentElement.append(message);
    }
    message.textContent = text;
}

function renderViralityLegend() {
    const legend = document.getElementById("viralityLegend");
    legend.replaceChildren();
    viralityLevels.forEach((level, index) => {
        const row = createElement("div", "legend-row");
        const label = createElement("span", "legend-label");
        const dot = createElement("i", "legend-dot");
        dot.style.backgroundColor = chartColors[index];
        dot.setAttribute("aria-hidden", "true");
        label.append(dot, document.createTextNode(level));
        row.append(label);
        legend.append(row);
    });
}

function getTrendCardRanking(data = dashboardData) {
    return data.trends.map(trend => {
        const trendUsages = data.usages.filter(usage => usage.trendId === trend.id);
        const usage = trendUsages.reduce(
            (total, item) => total + Number(item.usageCount || 0),
            0
        );
        const topUsage = trendUsages.reduce((top, item) =>
            Number(item.usageCount || 0) > Number(top?.usageCount || 0) ? item : top,
        null);
        const audio = data.audios.find(item => item.id === topUsage?.audioId);
        const score = trendUsages.reduce((highest, item) =>
            scoreValue(item.viralityScore) > scoreValue(highest)
                ? item.viralityScore
                : highest,
        "Low");

        return { trend, audio, usage, score };
    });
}

function getTrendingRanking(data = dashboardData) {
    const ranking = [];
    data.audios.forEach(audio => {
        const audioUsages = data.usages.filter(usage => usage.audioId === audio.id);
        if (audioUsages.length === 0) {
            return;
        }

        let usage = 0;
        let score = "Low";
        let topTrendUsage = -1;
        let topTrend = null;
        audioUsages.forEach(item => {
            const usageCount = Number(item.usageCount || 0);
            usage += usageCount;
            if (usageCount > topTrendUsage) {
                topTrendUsage = usageCount;
                topTrend = data.trends.find(trend => trend.id === item.trendId) || null;
            }
            if (scoreValue(item.viralityScore) > scoreValue(score)) {
                score = item.viralityScore;
            }
        });
        ranking.push({ audio, usage, trend: topTrend, score });
    });

    return ranking.sort((first, second) => {
        const scoreDifference = scoreValue(second.score) - scoreValue(first.score);
        return scoreDifference || second.usage - first.usage;
    });
}

function getAudioUsage(audioId) {
    return dashboardData.usages
        .filter(usage => usage.audioId === audioId)
        .reduce((sum, usage) => sum + Number(usage.usageCount || 0), 0);
}

function getAudioDescription(audio) {
    if (typeof audio.description === "string" && audio.description.trim()) {
        return audio.description.trim();
    }

    const linkedTrends = dashboardData.usages
        .filter(usage => usage.audioId === audio.id)
        .map(usage => ({
            usage,
            trend: dashboardData.trends.find(item => item.id === usage.trendId)
        }))
        .filter(item => typeof item.trend?.description === "string" && item.trend.description.trim())
        .sort((first, second) =>
            Number(second.usage.usageCount || 0) - Number(first.usage.usageCount || 0)
        );

    return linkedTrends[0]?.trend.description.trim() || "";
}

function scoreValue(score) {
    if (score === "High") return 3;
    if (score === "Medium") return 2;
    return 1;
}

function createArtwork(type, subject, alt, className) {
    const artwork = createElement("div", className);
    const img = document.createElement("img");
    img.src = getArtworkUrl(type, subject);
    img.alt = alt;
    img.loading = "lazy";
    img.addEventListener("error", () => {
        img.hidden = true;
        artwork.classList.add("image-fallback");
    }, { once: true });
    artwork.append(img);
    return artwork;
}

function getArtworkUrl(type, subject) {
    const normalized = String(subject || "").toLowerCase();
    const set = artworkImages[type] || artworkImages.audio;
    const keyword = Object.keys(set).find(key =>
        key !== "default" && normalized.includes(key)
    );
    const photoId = set[keyword || "default"];
    return `https://images.unsplash.com/${photoId}?auto=format&fit=crop&w=900&q=80`;
}

function createViralityBadge(level) {
    const safeLevel = viralityLevels.includes(level) ? level : "Low";
    return createTextElement("span", `badge badge-${safeLevel.toLowerCase()}`, safeLevel);
}

function createEmptyState(message) {
    return createTextElement("div", "empty-state", message);
}

function createElement(tag, className) {
    const element = document.createElement(tag);
    if (className) {
        element.className = className;
    }
    return element;
}

function createTextElement(tag, className, text) {
    const element = createElement(tag, className);
    element.textContent = String(text ?? "");
    return element;
}

function formatNumber(value) {
    return numberFormatter.format(Number(value || 0));
}

function normalize(value) {
    return String(value || "").trim().toLowerCase();
}