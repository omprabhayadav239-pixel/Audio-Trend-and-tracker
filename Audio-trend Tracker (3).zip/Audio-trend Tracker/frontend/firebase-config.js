import { initializeApp } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { getFunctions } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-functions.js";

const firebaseConfig = {
    apiKey: "AIzaSyCOySVIHtGFXX98ibz6-CGiErJ3vr-StRA",
    authDomain: "audio-trend-tracker-5346c.firebaseapp.com",
    databaseURL: "https://audio-trend-tracker-5346c-default-rtdb.firebaseio.com",
    projectId: "audio-trend-tracker-5346c",
    appId: "1:1097124862619:web:8eb2e590cd09f06c5d843e",

};

export const firebaseConfigured =
    Boolean(firebaseConfig.apiKey) &&
    firebaseConfig.apiKey !== "YOUR_FIREBASE_WEB_API_KEY" &&
    Boolean(firebaseConfig.appId) &&
    firebaseConfig.appId !== "YOUR_FIREBASE_WEB_APP_ID";

const firebaseApp = firebaseConfigured ? initializeApp(firebaseConfig) : null;
export const auth = firebaseApp ? getAuth(firebaseApp) : null;
export const functions = firebaseApp
    ? getFunctions(firebaseApp, "us-central1")
    : null;
