# Firebase backend setup

This project uses Firebase Authentication, a callable Cloud Functions API, and
Realtime Database. The Cloud Functions Admin SDK reads and writes tracker data
at `/trackerData`; browser clients cannot access the database directly.

## Configure the web app

1. In Firebase Console, add or select the Firebase Web App for project
   `audio-trend-tracker-5346c`.
2. Copy its `apiKey` and `appId` into `frontend/firebase-config.js`, replacing
   `YOUR_FIREBASE_WEB_API_KEY` and `YOUR_FIREBASE_WEB_APP_ID`.
3. In Authentication > Sign-in method, enable Email/Password.
4. In Authentication > Settings > Authorized domains, add the domain where the
   app will be hosted.

## Install and deploy

Install Node.js 22 and the Firebase CLI, authenticate with
`firebase login`, then run these commands from the project root:

```text
npm --prefix backend/functions install
firebase deploy --only hosting,functions,database
```

Cloud Functions deployment may require the Firebase project to use the Blaze
billing plan. Deploying the database rules blocks direct client reads/writes;
the Admin SDK used by authenticated Cloud Functions continues to have access.

For local development, serve the frontend over HTTP(S) rather than opening the
HTML files as `file://` URLs. Firebase Authentication and browser module imports
require a web origin.
