const { initializeApp } = require("firebase-admin/app");
const { getDatabase } = require("firebase-admin/database");
const { HttpsError, onCall } = require("firebase-functions/v2/https");

initializeApp({
    databaseURL: "https://audio-trend-tracker-5346c-default-rtdb.firebaseio.com"
});

const trackerDataRef = getDatabase().ref("trackerData");
const MAX_RECORDS_PER_COLLECTION = 1000;
const MAX_PAYLOAD_BYTES = 1024 * 1024;
const ALLOWED_COLLECTIONS = ["audios", "trends", "usages"];

function requireAuthenticatedUser(request) {
    if (!request.auth) {
        throw new HttpsError("unauthenticated", "Sign in to access tracker data.");
    }
}

function validateTrackerData(data) {
    if (!data || typeof data !== "object" || Array.isArray(data)) {
        throw new HttpsError("invalid-argument", "Tracker data must be an object.");
    }

    for (const collection of ALLOWED_COLLECTIONS) {
        const records = data[collection];
        if (!Array.isArray(records) || records.length > MAX_RECORDS_PER_COLLECTION) {
            throw new HttpsError(
                "invalid-argument",
                `${collection} must be an array with at most ${MAX_RECORDS_PER_COLLECTION} records.`
            );
        }

        for (const record of records) {
            if (!record || typeof record !== "object" || Array.isArray(record) ||
                typeof record.id !== "string" || record.id.length > 160) {
                throw new HttpsError("invalid-argument", `Every ${collection} record needs a valid id.`);
            }
        }
    }

    if (Buffer.byteLength(JSON.stringify(data), "utf8") > MAX_PAYLOAD_BYTES) {
        throw new HttpsError("resource-exhausted", "Tracker data exceeds the 1 MB limit.");
    }
}

exports.getTrackerData = onCall({ region: "us-central1" }, async request => {
    requireAuthenticatedUser(request);

    const snapshot = await trackerDataRef.get();
    return snapshot.exists() ? snapshot.val() : null;
});

exports.saveTrackerData = onCall({ region: "us-central1" }, async request => {
    requireAuthenticatedUser(request);
    validateTrackerData(request.data);

    await trackerDataRef.set({
        audios: request.data.audios,
        trends: request.data.trends,
        usages: request.data.usages,
        updatedAt: new Date().toISOString(),
        updatedBy: request.auth.uid
    });

    return { saved: true };
});
